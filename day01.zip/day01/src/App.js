import React from "react";
// import 참조변수 from './컴포넌트경로'

// import Aa from "./components/aa";
// import Test1 from "./components/Test1";
// import Test2 from "./components/Test2";
// import Test3 from "./components/Test3";
// import Test4 from "./components/Test4";
// import Test5 from "./components/Test5";
import Test6 from "./components/Test6";

const App = () => {
  return (
    <div>
      {/* <h2>안녕하세요</h2> */}
      {/* <Aa /> */}
      {/* <Test1 /> */}
      {/* <Test2 /> */}
      {/* <Test3 /> */}
      {/* <Test4 /> */}
      {/* <Test5 /> */}
      <Test6 />
    </div>
  );
};

export default App;
