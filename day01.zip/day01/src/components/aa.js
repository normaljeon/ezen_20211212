import React from "react";

// 파일 확장자는 .js 또는 .jsx 를 쓸 수 있다(확장 프로그램에 따라 오류가 있을 순 있음)
// 컴포넌트명과 파일명은 무관하다. 편의상 파일명과 컴포넌트명을 일치시킴
// 컴포넌트명은 대문자로 시작
const Aa = () => {
  return (
    <div>
      <h2>JSX영역</h2>
    </div>
  );
};

export default Aa;
